def baz():
    return 'baz'
